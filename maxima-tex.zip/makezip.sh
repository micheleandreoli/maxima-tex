#!/bin/sh

# makezip.sh
# (C) M. Andreoli 2023

#set -x

MAXIMA_DIR=$(basename `pwd`)

# copy src
cp /etc/my/bin/compute.maxima /etc/my/tex/maxima.tex .

# setup maxima.tex

cp setup/maxima-linux.tex maxima.tex


# make zip

rm -r img maxima.status maxima-tex.zip 2>/dev/null

zip -r maxima-tex.zip *


# end
